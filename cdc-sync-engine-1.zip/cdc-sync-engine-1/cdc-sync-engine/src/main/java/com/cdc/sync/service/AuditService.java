package com.cdc.sync.service;

import com.cdc.sync.entity.AuditLog;
import com.cdc.sync.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * Audits every synchronization event (requirement #15).
 */
@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    public void record(String eventId, String action, String entityType, String details, String correlationId) {
        auditLogRepository.save(AuditLog.builder()
                .eventId(eventId)
                .action(action)
                .entityType(entityType)
                .details(details)
                .timestamp(Instant.now())
                .correlationId(correlationId)
                .build());
    }
}
