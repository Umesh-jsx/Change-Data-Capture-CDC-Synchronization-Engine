package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;
import com.cdc.sync.repository.ChangeLogEntryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Simulates a Debezium/WAL change stream for the "local" (H2, no Kafka) profile
 * so the full pipeline is exercisable without external infrastructure. Every
 * poll interval it manufactures a handful of change events across the five
 * business entities and appends them to change_log_entry, exactly as the
 * KafkaChangeConsumer would when running against real Debezium topics in the
 * "docker" profile.
 */
@Service
@Profile("local")
@RequiredArgsConstructor
@Slf4j
public class CdcCaptureService {

    private static final String[] ENTITY_TYPES = {"ORDER", "CUSTOMER", "PRODUCT", "INVENTORY", "PAYMENT"};
    private static final String[] OPERATIONS = {"CREATE", "UPDATE", "DELETE"};

    private final ChangeLogEntryRepository changeLogEntryRepository;
    private final Random random = new Random();

    @Scheduled(fixedDelayString = "${cdc.poll-interval-ms}")
    public void captureChanges() {
        int batchSize = 1 + random.nextInt(4);
        List<ChangeLogEntry> batch = new java.util.ArrayList<>();
        for (int i = 0; i < batchSize; i++) {
            String entityType = ENTITY_TYPES[random.nextInt(ENTITY_TYPES.length)];
            String operation = OPERATIONS[random.nextInt(OPERATIONS.length)];
            String key = entityType.toLowerCase() + "-" + (1000 + random.nextInt(9000));

            ChangeLogEntry entry = ChangeLogEntry.builder()
                    .eventId(UUID.randomUUID().toString())
                    .entityType(entityType)
                    .operation(operation)
                    .entityKey(key)
                    .payload(String.format(
                            "{\"entity\":\"%s\",\"operation\":\"%s\",\"key\":\"%s\",\"timestamp\":\"%s\"}",
                            entityType, operation, key, Instant.now()))
                    .capturedAt(Instant.now())
                    .processed(false)
                    .build();
            batch.add(entry);
        }
        changeLogEntryRepository.saveAll(batch);
        log.debug("Captured {} simulated change events", batch.size());
    }
}
