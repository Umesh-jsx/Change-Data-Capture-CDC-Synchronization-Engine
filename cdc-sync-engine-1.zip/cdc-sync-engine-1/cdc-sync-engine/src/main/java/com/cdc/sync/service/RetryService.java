package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;
import com.cdc.sync.entity.FailedEvent;
import com.cdc.sync.repository.FailedEventRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

/**
 * Automatic retry with exponential backoff (requirement #8) for entries in
 * the Dead Letter Queue (requirement #7). Runs on a fixed schedule, picks up
 * any FailedEvent whose nextRetryAt has elapsed, and re-attempts the
 * Elasticsearch sync. After cdc.retry.max-attempts, the event is marked
 * EXHAUSTED and left for manual inspection via /api/failed-events.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class RetryService {

    private final FailedEventRepository failedEventRepository;
    private final ElasticsearchSyncService elasticsearchSyncService;
    private final AuditService auditService;

    @Value("${cdc.retry.max-attempts}")
    private int maxAttempts;

    @Value("${cdc.retry.initial-backoff-ms}")
    private long initialBackoffMs;

    @Value("${cdc.retry.multiplier}")
    private double multiplier;

    @Scheduled(fixedDelayString = "${cdc.poll-interval-ms}")
    public void retryFailedEvents() {
        List<FailedEvent> due = failedEventRepository.findByStatusAndNextRetryAtBefore("PENDING", Instant.now());
        for (FailedEvent failedEvent : due) {
            retryOne(failedEvent);
        }
    }

    private void retryOne(FailedEvent failedEvent) {
        MDC.put("correlationId", failedEvent.getCorrelationId());
        try {
            ChangeLogEntry reconstructed = ChangeLogEntry.builder()
                    .eventId(failedEvent.getEventId())
                    .entityType(failedEvent.getEntityType())
                    .operation("RETRY")
                    .entityKey(failedEvent.getEventId())
                    .payload(failedEvent.getPayload())
                    .capturedAt(failedEvent.getFirstFailedAt())
                    .build();

            elasticsearchSyncService.index(reconstructed);

            failedEvent.setStatus("RESOLVED");
            failedEventRepository.save(failedEvent);
            auditService.record(failedEvent.getEventId(), "RETRIED", failedEvent.getEntityType(),
                    "Retry succeeded on attempt " + (failedEvent.getAttemptCount() + 1), failedEvent.getCorrelationId());
            log.info("Retry succeeded for event {}", failedEvent.getEventId());

        } catch (Exception ex) {
            int newAttempt = failedEvent.getAttemptCount() + 1;
            failedEvent.setAttemptCount(newAttempt);
            failedEvent.setErrorMessage(ex.getMessage());

            if (newAttempt >= maxAttempts) {
                failedEvent.setStatus("EXHAUSTED");
                auditService.record(failedEvent.getEventId(), "FAILED", failedEvent.getEntityType(),
                        "Exhausted after " + newAttempt + " attempts: " + ex.getMessage(), failedEvent.getCorrelationId());
                log.error("Event {} exhausted retries", failedEvent.getEventId());
            } else {
                long backoffMs = (long) (initialBackoffMs * Math.pow(multiplier, newAttempt));
                failedEvent.setNextRetryAt(Instant.now().plusMillis(backoffMs));
                auditService.record(failedEvent.getEventId(), "RETRIED", failedEvent.getEntityType(),
                        "Retry attempt " + newAttempt + " failed, next retry in " + backoffMs + "ms", failedEvent.getCorrelationId());
            }
            failedEventRepository.save(failedEvent);
        } finally {
            MDC.remove("correlationId");
        }
    }
}
