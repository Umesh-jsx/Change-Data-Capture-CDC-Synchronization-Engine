package com.cdc.sync.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Entity
@Table(name = "change_log_entry")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChangeLogEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String eventId;

    @Column(nullable = false)
    private String entityType;

    @Column(nullable = false)
    private String operation;

    @Column(nullable = false)
    private String entityKey;

    @Lob
    private String payload;

    @Column(nullable = false)
    private Instant capturedAt;

    @Builder.Default
    private boolean processed = false;
}
