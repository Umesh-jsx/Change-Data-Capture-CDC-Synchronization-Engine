package com.cdc.sync.service;

import com.cdc.sync.dto.SyncStatusResponse;
import com.cdc.sync.repository.ChangeLogEntryRepository;
import com.cdc.sync.repository.FailedEventRepository;
import com.cdc.sync.repository.ProcessingStatusRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SyncStatusService {

    private final ChangeLogEntryRepository changeLogEntryRepository;
    private final ProcessingStatusRepository processingStatusRepository;
    private final FailedEventRepository failedEventRepository;

    @Value("${cdc.mode}")
    private String mode;

    public SyncStatusResponse getStatus() {
        return SyncStatusResponse.builder()
                .pendingChanges(changeLogEntryRepository.countByProcessedFalse())
                .processedEvents(processingStatusRepository.count())
                .failedEventsPending(failedEventRepository.findByStatus("PENDING").size())
                .failedEventsExhausted(failedEventRepository.findByStatus("EXHAUSTED").size())
                .mode(mode)
                .build();
    }
}
