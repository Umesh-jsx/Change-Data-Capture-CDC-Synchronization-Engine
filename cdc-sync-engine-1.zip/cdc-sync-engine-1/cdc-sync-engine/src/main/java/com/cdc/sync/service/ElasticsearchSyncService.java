package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;

public interface ElasticsearchSyncService {
    void index(ChangeLogEntry entry);
}
