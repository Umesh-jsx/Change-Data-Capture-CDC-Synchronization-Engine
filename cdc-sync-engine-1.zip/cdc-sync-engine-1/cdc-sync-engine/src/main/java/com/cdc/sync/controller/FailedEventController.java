package com.cdc.sync.controller;

import com.cdc.sync.dto.FailedEventResponse;
import com.cdc.sync.entity.FailedEvent;
import com.cdc.sync.exception.ResourceNotFoundException;
import com.cdc.sync.repository.FailedEventRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/failed-events")
@RequiredArgsConstructor
@Tag(name = "Failed Events / DLQ")
public class FailedEventController {

    private final FailedEventRepository failedEventRepository;

    @GetMapping
    @Operation(summary = "List failed events currently in the Dead Letter Queue")
    public List<FailedEventResponse> listFailed(@RequestParam(defaultValue = "PENDING") String status) {
        return failedEventRepository.findByStatus(status).stream()
                .map(this::toResponse)
                .toList();
    }

    @PostMapping("/{id}/retry-now")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Force an immediate retry of a failed event (ADMIN only)")
    public FailedEventResponse retryNow(@PathVariable Long id) {
        FailedEvent event = failedEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Failed event not found: " + id));
        event.setNextRetryAt(Instant.now());
        event.setStatus("PENDING");
        failedEventRepository.save(event);
        return toResponse(event);
    }

    private FailedEventResponse toResponse(FailedEvent e) {
        return FailedEventResponse.builder()
                .id(e.getId())
                .eventId(e.getEventId())
                .entityType(e.getEntityType())
                .errorMessage(e.getErrorMessage())
                .attemptCount(e.getAttemptCount())
                .nextRetryAt(e.getNextRetryAt())
                .status(e.getStatus())
                .build();
    }
}
