package com.cdc.sync.repository;

import com.cdc.sync.entity.ChangeLogEntry;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChangeLogEntryRepository extends JpaRepository<ChangeLogEntry, Long> {
    List<ChangeLogEntry> findTop100ByProcessedFalseOrderByCapturedAtAsc();
    long countByProcessedFalse();
}
