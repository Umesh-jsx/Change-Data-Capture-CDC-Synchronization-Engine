package com.cdc.sync.service;

import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * Caches synchronization metadata (requirement #14). Backed by Redis in the
 * "docker" profile and an in-memory ConcurrentMapCache in "local", selected
 * automatically via spring.cache.type in application.yml.
 */
@Service
public class SyncMetadataCacheService {

    @CachePut(value = "lastSyncTimestamps", key = "#entityType")
    public Instant recordLastSync(String entityType, Instant timestamp) {
        return timestamp;
    }

    @Cacheable(value = "lastSyncTimestamps", key = "#entityType")
    public Instant getLastSync(String entityType) {
        return null; // populated once recordLastSync has run for this entityType
    }
}
