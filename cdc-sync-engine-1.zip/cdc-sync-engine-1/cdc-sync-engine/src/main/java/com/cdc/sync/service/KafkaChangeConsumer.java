package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;
import com.cdc.sync.repository.ChangeLogEntryRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

/**
 * Consumes Debezium change events from Kafka Connect topics (requirement #3, #4).
 * Only active in the "docker" profile, once Zookeeper/Kafka/Debezium are running
 * per docker-compose.yml. Uses manual acknowledgement (requirement #5): the
 * offset is only committed after the event has been durably recorded in
 * change_log_entry and handed to EventProcessingService, so a consumer crash
 * mid-processing results in redelivery rather than data loss. Downstream
 * idempotency (ProcessingStatus lookup in EventProcessingService) makes that
 * redelivery safe.
 */
@Service
@Profile("docker")
@RequiredArgsConstructor
@Slf4j
public class KafkaChangeConsumer {

    private final ChangeLogEntryRepository changeLogEntryRepository;
    private final EventProcessingService eventProcessingService;
    private final AuditService auditService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = {
            "${kafka.topics.orders}",
            "${kafka.topics.customers}",
            "${kafka.topics.products}",
            "${kafka.topics.inventory}"
    }, containerFactory = "kafkaListenerContainerFactory")
    public void onMessage(ConsumerRecord<String, String> record, Acknowledgment ack) {
        String correlationId = UUID.randomUUID().toString();
        MDC.put("correlationId", correlationId);
        try {
            String entityType = inferEntityType(record.topic());
            String eventId = record.topic() + "-" + record.partition() + "-" + record.offset();

            ChangeLogEntry entry = ChangeLogEntry.builder()
                    .eventId(eventId)
                    .entityType(entityType)
                    .operation(extractOperation(record.value()))
                    .entityKey(record.key() != null ? record.key() : eventId)
                    .payload(record.value())
                    .capturedAt(Instant.now())
                    .processed(false)
                    .build();

            if (!changeLogEntryRepository.findTop100ByProcessedFalseOrderByCapturedAtAsc()
                    .stream().anyMatch(e -> e.getEventId().equals(eventId))) {
                changeLogEntryRepository.save(entry);
            }

            auditService.record(eventId, "CAPTURED", entityType, "Consumed from topic " + record.topic(), correlationId);

            eventProcessingService.process(entry);
            entry.setProcessed(true);
            changeLogEntryRepository.save(entry);

            ack.acknowledge(); // commit offset only after successful handling
        } catch (Exception ex) {
            log.error("Failed to handle Kafka record from {}: {}", record.topic(), ex.getMessage());
            // Do not acknowledge -> message will be redelivered; EventProcessingService's
            // own failure path (inside process()) already routes to the DLQ table for
            // application-level tracking independent of Kafka-level redelivery.
        } finally {
            MDC.remove("correlationId");
        }
    }

    private String inferEntityType(String topic) {
        if (topic.contains("order")) return "ORDER";
        if (topic.contains("customer")) return "CUSTOMER";
        if (topic.contains("product")) return "PRODUCT";
        if (topic.contains("inventory")) return "INVENTORY";
        return "UNKNOWN";
    }

    private String extractOperation(String debeziumJson) {
        try {
            JsonNode node = objectMapper.readTree(debeziumJson);
            String op = node.path("payload").path("op").asText("u");
            return switch (op) {
                case "c" -> "CREATE";
                case "u" -> "UPDATE";
                case "d" -> "DELETE";
                default -> "UNKNOWN";
            };
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }
}
