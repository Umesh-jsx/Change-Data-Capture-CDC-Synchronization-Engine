package com.cdc.sync.repository;

import com.cdc.sync.entity.FailedEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;

public interface FailedEventRepository extends JpaRepository<FailedEvent, Long> {
    List<FailedEvent> findByStatusAndNextRetryAtBefore(String status, Instant time);
    List<FailedEvent> findByStatus(String status);
}
