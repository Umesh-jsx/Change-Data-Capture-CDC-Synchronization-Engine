package com.cdc.sync.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Entity
@Table(name = "processing_status")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProcessingStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String eventId;

    @Column(nullable = false)
    private String entityType;

    @Column(nullable = false)
    private String status;

    @Column(nullable = false)
    private Instant processedAt;

    private long processingTimeMs;

    private String correlationId;
}
