package com.cdc.sync.controller;

import com.cdc.sync.dto.SyncStatusResponse;
import com.cdc.sync.service.SyncStatusService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/sync")
@RequiredArgsConstructor
@Tag(name = "Sync Status")
public class SyncStatusController {

    private final SyncStatusService syncStatusService;

    @GetMapping("/status")
    @Operation(summary = "View current CDC synchronization status")
    public SyncStatusResponse getStatus() {
        return syncStatusService.getStatus();
    }
}
