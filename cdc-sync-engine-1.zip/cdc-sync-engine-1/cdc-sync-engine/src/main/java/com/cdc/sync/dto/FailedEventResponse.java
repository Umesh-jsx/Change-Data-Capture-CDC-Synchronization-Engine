package com.cdc.sync.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FailedEventResponse {
    private Long id;
    private String eventId;
    private String entityType;
    private String errorMessage;
    private int attemptCount;
    private Instant nextRetryAt;
    private String status;
}
