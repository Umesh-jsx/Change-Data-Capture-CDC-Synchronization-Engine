package com.cdc.sync;

import com.cdc.sync.entity.AppUser;
import com.cdc.sync.repository.AppUserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Seeds default users at application startup using the live PasswordEncoder
 * bean, rather than shipping hardcoded BCrypt hashes in a SQL script (which
 * silently break if the encoder strength/algorithm ever changes).
 *
 * Default credentials (change immediately outside of local/dev use):
 *   admin    / Admin@123    -> ROLE_ADMIN
 *   operator / Operator@123 -> ROLE_OPERATOR
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (appUserRepository.findByUsername("admin").isEmpty()) {
            appUserRepository.save(AppUser.builder()
                    .username("admin")
                    .password(passwordEncoder.encode("Admin@123"))
                    .roles(Set.of("ADMIN"))
                    .enabled(true)
                    .build());
            log.info("Seeded default ADMIN user (username=admin / password=Admin@123)");
        }

        if (appUserRepository.findByUsername("operator").isEmpty()) {
            appUserRepository.save(AppUser.builder()
                    .username("operator")
                    .password(passwordEncoder.encode("Operator@123"))
                    .roles(Set.of("OPERATOR"))
                    .enabled(true)
                    .build());
            log.info("Seeded default OPERATOR user (username=operator / password=Operator@123)");
        }
    }
}
