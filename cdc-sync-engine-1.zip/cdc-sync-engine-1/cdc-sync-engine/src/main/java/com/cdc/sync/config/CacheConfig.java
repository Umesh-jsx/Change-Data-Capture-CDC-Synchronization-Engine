package com.cdc.sync.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

/**
 * Caching is enabled here; the actual CacheManager implementation is chosen
 * by Spring Boot autoconfiguration based on spring.cache.type:
 *  - "local" profile  -> spring.cache.type=simple  (in-memory ConcurrentMapCacheManager)
 *  - "docker" profile -> spring.cache.type=redis    (real Redis, matches spec requirement #14)
 * No manual CacheManager bean is required for either case.
 */
@Configuration
@EnableCaching
public class CacheConfig {
}
