package com.cdc.sync.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SyncStatusResponse {
    private long pendingChanges;
    private long processedEvents;
    private long failedEventsPending;
    private long failedEventsExhausted;
    private String mode; // simulated | kafka
}
