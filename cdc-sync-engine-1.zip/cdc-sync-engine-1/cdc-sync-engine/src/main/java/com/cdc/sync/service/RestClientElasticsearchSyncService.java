package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

/**
 * Real Elasticsearch sync used in the "docker" profile, against the ES node
 * started by docker-compose.yml. Uses a lightweight RestClient PUT to the
 * per-entity-type index rather than pulling in the full ES Java client, to
 * keep the dependency footprint small; swap for the official client if richer
 * query/aggregation features are later needed.
 */
@Service
@Profile("docker")
@Slf4j
public class RestClientElasticsearchSyncService implements ElasticsearchSyncService {

    private final RestClient restClient;

    public RestClientElasticsearchSyncService(@Value("${cdc.elasticsearch.uris}") String esUri) {
        this.restClient = RestClient.builder().baseUrl(esUri).build();
    }

    @Override
    public void index(ChangeLogEntry entry) {
        String index = entry.getEntityType().toLowerCase() + "s";
        try {
            restClient.put()
                    .uri("/{index}/_doc/{id}", index, entry.getEventId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                    .body(entry.getPayload())
                    .retrieve()
                    .toBodilessEntity();
        } catch (Exception e) {
            log.warn("Elasticsearch indexing failed for event {}: {}", entry.getEventId(), e.getMessage());
            throw e; // propagate so the caller's retry/DLQ logic engages
        }
    }
}
