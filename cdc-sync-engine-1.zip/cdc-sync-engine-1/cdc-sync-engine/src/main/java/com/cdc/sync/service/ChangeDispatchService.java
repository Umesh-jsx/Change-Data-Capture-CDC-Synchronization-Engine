package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;
import com.cdc.sync.repository.ChangeLogEntryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

/**
 * Drains unprocessed change_log_entry rows and runs them through
 * EventProcessingService. In the "local" profile this is what turns
 * CdcCaptureService's simulated WAL entries into synced/failed events.
 * (In "docker" profile, KafkaChangeConsumer performs the equivalent role
 * directly off real Kafka topics with manual ack, but also writes through
 * this same change_log_entry table + EventProcessingService so status
 * reporting and audit trails are identical across profiles.)
 */
@Service
@Profile("local")
@RequiredArgsConstructor
@Slf4j
public class ChangeDispatchService {

    private final ChangeLogEntryRepository changeLogEntryRepository;
    private final EventProcessingService eventProcessingService;
    private final AuditService auditService;

    @Scheduled(fixedDelayString = "${cdc.poll-interval-ms}")
    public void dispatchPendingChanges() {
        List<ChangeLogEntry> pending = changeLogEntryRepository.findTop100ByProcessedFalseOrderByCapturedAtAsc();
        if (pending.isEmpty()) {
            return;
        }
        String correlationId = UUID.randomUUID().toString();
        MDC.put("correlationId", correlationId);
        try {
            for (ChangeLogEntry entry : pending) {
                auditService.record(entry.getEventId(), "CAPTURED", entry.getEntityType(),
                        "Change captured: " + entry.getOperation() + " on " + entry.getEntityKey(), correlationId);
                eventProcessingService.process(entry);
                entry.setProcessed(true);
                changeLogEntryRepository.save(entry);
            }
            log.info("Dispatched {} change events (correlationId={})", pending.size(), correlationId);
        } finally {
            MDC.remove("correlationId");
        }
    }
}
