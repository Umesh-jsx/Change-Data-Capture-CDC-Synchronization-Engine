package com.cdc.sync.repository;

import com.cdc.sync.entity.ProcessingStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProcessingStatusRepository extends JpaRepository<ProcessingStatus, Long> {
    Optional<ProcessingStatus> findByEventId(String eventId);
    boolean existsByEventId(String eventId);
    long countByEntityType(String entityType);
}
