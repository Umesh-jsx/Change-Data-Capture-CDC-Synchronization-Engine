package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;
import com.cdc.sync.entity.FailedEvent;
import com.cdc.sync.entity.ProcessingStatus;
import com.cdc.sync.repository.FailedEventRepository;
import com.cdc.sync.repository.ProcessingStatusRepository;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * Central pipeline step shared by both the local simulated poller and the
 * Kafka consumer. Responsible for:
 *  - Idempotent Consumer Pattern (requirement #6): skip if ProcessingStatus already has this eventId
 *  - Synchronizing into Elasticsearch (requirement #10)
 *  - Auditing every event (requirement #15)
 *  - Recording Prometheus/Micrometer metrics (requirement #16)
 *  - On failure: routing to the Dead Letter Queue with exponential-backoff retry scheduling (requirements #7, #8)
 */
@Service
@Slf4j
public class EventProcessingService {

    private final ProcessingStatusRepository processingStatusRepository;
    private final FailedEventRepository failedEventRepository;
    private final ElasticsearchSyncService elasticsearchSyncService;
    private final AuditService auditService;
    private final SyncMetadataCacheService syncMetadataCacheService;

    private final Counter processedCounter;
    private final Counter failedCounter;
    private final Timer processingTimer;

    @Value("${cdc.retry.initial-backoff-ms}")
    private long initialBackoffMs;

    public EventProcessingService(ProcessingStatusRepository processingStatusRepository,
                                   FailedEventRepository failedEventRepository,
                                   ElasticsearchSyncService elasticsearchSyncService,
                                   AuditService auditService,
                                   SyncMetadataCacheService syncMetadataCacheService,
                                   MeterRegistry meterRegistry) {
        this.processingStatusRepository = processingStatusRepository;
        this.failedEventRepository = failedEventRepository;
        this.elasticsearchSyncService = elasticsearchSyncService;
        this.auditService = auditService;
        this.syncMetadataCacheService = syncMetadataCacheService;
        this.processedCounter = meterRegistry.counter("cdc.events.processed");
        this.failedCounter = meterRegistry.counter("cdc.events.failed");
        this.processingTimer = meterRegistry.timer("cdc.events.processing.time");
    }

    /**
     * Processes a single captured change. Returns true if the event was (or
     * had already been) successfully applied, false if it was sent to the DLQ.
     */
    public boolean process(ChangeLogEntry entry) {
        String correlationId = MDC.get("correlationId");

        if (processingStatusRepository.existsByEventId(entry.getEventId())) {
            log.debug("Event {} already processed, skipping (idempotent consumer)", entry.getEventId());
            return true;
        }

        long start = System.currentTimeMillis();
        try {
            return processingTimer.recordCallable(() -> {
                elasticsearchSyncService.index(entry);

                long elapsed = System.currentTimeMillis() - start;
                processingStatusRepository.save(ProcessingStatus.builder()
                        .eventId(entry.getEventId())
                        .entityType(entry.getEntityType())
                        .status("SUCCESS")
                        .processedAt(Instant.now())
                        .processingTimeMs(elapsed)
                        .correlationId(correlationId)
                        .build());

                auditService.record(entry.getEventId(), "SYNCED_TO_ES", entry.getEntityType(),
                        "Synced to Elasticsearch in " + elapsed + "ms", correlationId);

                syncMetadataCacheService.recordLastSync(entry.getEntityType(), Instant.now());
                processedCounter.increment();
                return true;
            });
        } catch (Exception ex) {
            failedCounter.increment();
            handleFailure(entry, ex, correlationId);
            return false;
        }
    }

    private void handleFailure(ChangeLogEntry entry, Exception ex, String correlationId) {
        FailedEvent failedEvent = FailedEvent.builder()
                .eventId(entry.getEventId())
                .entityType(entry.getEntityType())
                .payload(entry.getPayload())
                .errorMessage(ex.getMessage())
                .attemptCount(1)
                .firstFailedAt(Instant.now())
                .nextRetryAt(Instant.now().plusMillis(initialBackoffMs))
                .status("PENDING")
                .correlationId(correlationId)
                .build();
        failedEventRepository.save(failedEvent);

        auditService.record(entry.getEventId(), "DLQ", entry.getEntityType(),
                "Routed to DLQ after initial failure: " + ex.getMessage(), correlationId);
        log.warn("Event {} routed to DLQ: {}", entry.getEventId(), ex.getMessage());
    }
}
