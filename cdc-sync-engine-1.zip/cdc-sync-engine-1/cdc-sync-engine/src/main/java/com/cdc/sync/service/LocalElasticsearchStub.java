package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/**
 * Local-profile stand-in for Elasticsearch. There is no ES cluster available
 * without Docker, so this simply logs what WOULD be indexed. Swapped out for
 * RestClientElasticsearchSyncService automatically when spring.profiles.active=docker.
 */
@Service
@Profile("local")
@Slf4j
public class LocalElasticsearchStub implements ElasticsearchSyncService {

    @Override
    public void index(ChangeLogEntry entry) {
        log.info("[ES-STUB] would index {} '{}' (op={}) into Elasticsearch", entry.getEntityType(), entry.getEntityKey(), entry.getOperation());
    }
}
