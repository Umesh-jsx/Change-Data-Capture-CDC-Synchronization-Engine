package com.cdc.sync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CdcSyncEngineApplication {

    public static void main(String[] args) {
        SpringApplication.run(CdcSyncEngineApplication.class, args);
    }
}
