package com.cdc.sync.service;

import com.cdc.sync.entity.ChangeLogEntry;
import com.cdc.sync.entity.ProcessingStatus;
import com.cdc.sync.repository.FailedEventRepository;
import com.cdc.sync.repository.ProcessingStatusRepository;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EventProcessingServiceTest {

    @Mock
    private ProcessingStatusRepository processingStatusRepository;
    @Mock
    private FailedEventRepository failedEventRepository;
    @Mock
    private ElasticsearchSyncService elasticsearchSyncService;
    @Mock
    private AuditService auditService;
    @Mock
    private SyncMetadataCacheService syncMetadataCacheService;

    private EventProcessingService eventProcessingService;

    @BeforeEach
    void setUp() {
        eventProcessingService = new EventProcessingService(
                processingStatusRepository,
                failedEventRepository,
                elasticsearchSyncService,
                auditService,
                syncMetadataCacheService,
                new SimpleMeterRegistry());
    }

    private ChangeLogEntry sampleEntry() {
        return ChangeLogEntry.builder()
                .eventId("evt-1")
                .entityType("ORDER")
                .operation("CREATE")
                .entityKey("order-1001")
                .payload("{}")
                .capturedAt(Instant.now())
                .build();
    }

    @Test
    void skipsAlreadyProcessedEvent_idempotency() {
        when(processingStatusRepository.existsByEventId("evt-1")).thenReturn(true);

        boolean result = eventProcessingService.process(sampleEntry());

        assertTrue(result);
        verifyNoInteractions(elasticsearchSyncService);
        verify(processingStatusRepository, never()).save(any());
    }

    @Test
    void processesNewEventSuccessfully() {
        when(processingStatusRepository.existsByEventId("evt-1")).thenReturn(false);

        boolean result = eventProcessingService.process(sampleEntry());

        assertTrue(result);
        verify(elasticsearchSyncService).index(any(ChangeLogEntry.class));
        verify(processingStatusRepository).save(any(ProcessingStatus.class));
        verify(auditService).record(eq("evt-1"), eq("SYNCED_TO_ES"), eq("ORDER"), any(), any());
    }

    @Test
    void routesToDlqOnFailure() {
        when(processingStatusRepository.existsByEventId("evt-1")).thenReturn(false);
        doThrow(new RuntimeException("ES down")).when(elasticsearchSyncService).index(any());

        boolean result = eventProcessingService.process(sampleEntry());

        assertFalse(result);
        verify(failedEventRepository).save(any());
        verify(auditService).record(eq("evt-1"), eq("DLQ"), eq("ORDER"), any(), any());
    }
}
