package com.cdc.sync.controller;

import com.cdc.sync.dto.SyncStatusResponse;
import com.cdc.sync.security.JwtUtil;
import com.cdc.sync.service.SyncStatusService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SyncStatusController.class)
class SyncStatusControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SyncStatusService syncStatusService;

    @MockBean
    private JwtUtil jwtUtil; // required by JwtAuthFilter on the security filter chain

    @Test
    @WithMockUser(roles = {"OPERATOR"})
    void returnsSyncStatus() throws Exception {
        when(syncStatusService.getStatus()).thenReturn(SyncStatusResponse.builder()
                .pendingChanges(5)
                .processedEvents(120)
                .failedEventsPending(1)
                .failedEventsExhausted(0)
                .mode("simulated")
                .build());

        mockMvc.perform(get("/api/sync/status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.processedEvents").value(120))
                .andExpect(jsonPath("$.mode").value("simulated"));
    }

    @Test
    void rejectsUnauthenticatedRequest() throws Exception {
        mockMvc.perform(get("/api/sync/status"))
                .andExpect(status().is4xxClientError());
    }
}
