package com.cdc.sync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("local")
class CdcSyncEngineApplicationTests {

    @Test
    void contextLoads() {
        // Verifies the full Spring context (local/H2 profile) wires up without errors.
    }
}
