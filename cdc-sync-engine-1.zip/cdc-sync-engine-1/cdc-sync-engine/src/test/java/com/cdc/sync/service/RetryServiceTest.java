package com.cdc.sync.service;

import com.cdc.sync.entity.FailedEvent;
import com.cdc.sync.repository.FailedEventRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RetryServiceTest {

    @Mock
    private FailedEventRepository failedEventRepository;
    @Mock
    private ElasticsearchSyncService elasticsearchSyncService;
    @Mock
    private AuditService auditService;

    private RetryService retryService;

    @BeforeEach
    void setUp() {
        retryService = new RetryService(failedEventRepository, elasticsearchSyncService, auditService);
        ReflectionTestUtils.setField(retryService, "maxAttempts", 3);
        ReflectionTestUtils.setField(retryService, "initialBackoffMs", 1000L);
        ReflectionTestUtils.setField(retryService, "multiplier", 2.0);
    }

    private FailedEvent sampleFailedEvent(int attemptCount) {
        return FailedEvent.builder()
                .id(1L)
                .eventId("evt-1")
                .entityType("ORDER")
                .payload("{}")
                .attemptCount(attemptCount)
                .firstFailedAt(Instant.now())
                .nextRetryAt(Instant.now())
                .status("PENDING")
                .correlationId("corr-1")
                .build();
    }

    @Test
    void marksResolvedWhenRetrySucceeds() {
        FailedEvent event = sampleFailedEvent(1);
        when(failedEventRepository.findByStatusAndNextRetryAtBefore(eq("PENDING"), any())).thenReturn(List.of(event));

        retryService.retryFailedEvents();

        assertEquals("RESOLVED", event.getStatus());
        verify(failedEventRepository).save(event);
    }

    @Test
    void marksExhaustedAfterMaxAttempts() {
        FailedEvent event = sampleFailedEvent(2); // next failure -> attempt 3 == maxAttempts
        when(failedEventRepository.findByStatusAndNextRetryAtBefore(eq("PENDING"), any())).thenReturn(List.of(event));
        doThrow(new RuntimeException("still down")).when(elasticsearchSyncService).index(any());

        retryService.retryFailedEvents();

        assertEquals("EXHAUSTED", event.getStatus());
        assertEquals(3, event.getAttemptCount());
    }

    @Test
    void schedulesNextBackoffWhenAttemptsRemain() {
        FailedEvent event = sampleFailedEvent(0);
        when(failedEventRepository.findByStatusAndNextRetryAtBefore(eq("PENDING"), any())).thenReturn(List.of(event));
        doThrow(new RuntimeException("still down")).when(elasticsearchSyncService).index(any());

        retryService.retryFailedEvents();

        assertEquals("PENDING", event.getStatus());
        assertEquals(1, event.getAttemptCount());
    }
}
