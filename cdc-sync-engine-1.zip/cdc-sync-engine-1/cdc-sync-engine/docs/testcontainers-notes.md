# Adding a Testcontainers integration test

Not included by default because it requires a running Docker daemon at test
time, which not every Eclipse/CI setup has available. To add one:

```java
@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("docker")
class CdcPipelineIntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("debezium/postgres:15")
            .withDatabaseName("cdcdb").withUsername("cdc_user").withPassword("cdc_pass");

    @Container
    static KafkaContainer kafka = new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:7.6.0"));

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
        registry.add("kafka.bootstrap-servers", kafka::getBootstrapServers);
    }

    // Insert a row via JDBC, register a Debezium connector against the
    // container's exposed Kafka Connect (or push a message onto the topic
    // directly to test just the consumer), then poll GET /api/sync/status
    // until processedEvents increments.
}
```

The `testcontainers`, `junit-jupiter`, `postgresql`, and `kafka` Testcontainers
modules are already declared as test-scope dependencies in `pom.xml`, so this
drops in without any pom changes.
