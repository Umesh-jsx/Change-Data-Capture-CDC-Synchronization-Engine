# ER Diagram

Note: `orders`, `customers`, `products`, `inventory`, `payments` are the
*source* e-commerce tables (owned by whatever upstream service already
manages them — Debezium reads their WAL, it doesn't define their schema
here). The tables below are the ones this application owns.

```mermaid
erDiagram
    APP_USER {
        bigint id PK
        varchar username UK
        varchar password
        boolean enabled
    }
    APP_USER_ROLES {
        bigint app_user_id FK
        varchar roles
    }
    CHANGE_LOG_ENTRY {
        bigint id PK
        varchar event_id UK
        varchar entity_type
        varchar operation
        varchar entity_key
        text payload
        timestamp captured_at
        boolean processed
    }
    PROCESSING_STATUS {
        bigint id PK
        varchar event_id UK
        varchar entity_type
        varchar status
        timestamp processed_at
        bigint processing_time_ms
        varchar correlation_id
    }
    FAILED_EVENT {
        bigint id PK
        varchar event_id
        varchar entity_type
        text payload
        text error_message
        int attempt_count
        timestamp next_retry_at
        timestamp first_failed_at
        varchar status
        varchar correlation_id
    }
    AUDIT_LOG {
        bigint id PK
        varchar event_id
        varchar action
        varchar entity_type
        text details
        timestamp timestamp
        varchar correlation_id
    }

    APP_USER ||--o{ APP_USER_ROLES : has
    CHANGE_LOG_ENTRY ||--o| PROCESSING_STATUS : "produces (on success)"
    CHANGE_LOG_ENTRY ||--o| FAILED_EVENT : "produces (on failure)"
    CHANGE_LOG_ENTRY ||--o{ AUDIT_LOG : "generates"
```

`event_id` is the natural join key across `change_log_entry`,
`processing_status`, `failed_event`, and `audit_log` — it is NOT a foreign
key constraint in the schema (failed/audit records must be insertable even
if the originating change_log_entry row is later archived), but it's how
you'd trace one change's full lifecycle in a query.
