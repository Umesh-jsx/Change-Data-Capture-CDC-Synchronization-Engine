# Performance Report

This is a template, not a fabricated benchmark — fill in the actual numbers
after a load run against your environment. Suggested method:

1. In `local` profile, temporarily drop `cdc.poll-interval-ms` to 100 and let
   `CdcCaptureService` run for the duration of the test, or write a small
   test harness that inserts N rows directly into `change_log_entry`.
2. In `docker` profile, use `pgbench` or a script that issues real
   INSERT/UPDATE/DELETE statements against the Postgres source tables so the
   test exercises the actual Debezium → Kafka → consumer path.
3. Pull the numbers from `/actuator/prometheus`:
   - `cdc_events_processed_total`
   - `cdc_events_failed_total`
   - `cdc_events_processing_time_seconds_sum` / `_count` for average latency
   - `cdc_events_processing_time_seconds_max` for worst-case latency

| Metric | Target (NFR) | Observed |
|---|---|---|
| Events processed without data loss | ≥ 10,000 | _fill in_ |
| Average processing latency per event | _fill in_ | _fill in_ |
| P95 / P99 latency | _fill in_ | _fill in_ |
| Throughput (events/sec) | _fill in_ | _fill in_ |
| Consumer recovery time after Kafka restart | _fill in_ | _fill in_ |
| Failed events auto-recovered via retry | _fill in_ | _fill in_ |
| Events reaching EXHAUSTED (manual triage) | _fill in_ | _fill in_ |

## Notes on exactly-once processing

Verify this by intentionally redelivering a Kafka message (e.g., reset the
consumer group offset) and confirming `cdc_events_processed_total` does not
increase for that event id, and no duplicate document is written to the
corresponding Elasticsearch index — `ProcessingStatus.eventId`'s uniqueness
constraint is what should prevent the duplicate application.
