# Architecture

```mermaid
flowchart LR
    subgraph Source["PostgreSQL (Orders, Customers, Products, Inventory, Payments)"]
        DB[(orders / customers / products / inventory / payments)]
    end

    DB -- WAL --> Debezium[Debezium Kafka Connect]
    Debezium --> Kafka[(Kafka topics: dbserver1.public.*)]
    Kafka --> Consumer[KafkaChangeConsumer\nmanual ack, 3x concurrency]

    Consumer --> ChangeLog[(change_log_entry)]
    ChangeLog --> Processor[EventProcessingService\nidempotency check via ProcessingStatus]

    Processor -->|success| ES[(Elasticsearch)]
    Processor -->|success| Audit[(audit_log)]
    Processor -->|success| Cache[(Redis: sync metadata)]
    Processor -->|failure| DLQ[(failed_event / DLQ)]

    DLQ --> Retry[RetryService\nexponential backoff]
    Retry -->|success| ES
    Retry -->|exhausted| DLQ

    API[REST API\nJWT + RBAC] --> ChangeLog
    API --> DLQ
    API --> Audit

    Processor --> Metrics[Micrometer]
    Metrics --> Prometheus[(Prometheus)]
    Prometheus --> Grafana[Grafana Dashboards]
```

## Layered structure

- **controller** — REST endpoints, JWT-protected, role-checked (ADMIN /
  OPERATOR) via Spring Security method + URL security.
- **service** — all business logic. `CdcCaptureService` /
  `ChangeDispatchService` (local profile) and `KafkaChangeConsumer` (docker
  profile) are the two interchangeable *front doors* into the pipeline;
  both feed the same `EventProcessingService`, so idempotency, DLQ, audit
  and metrics behavior is identical regardless of profile.
- **repository** — Spring Data JPA, one repository per entity.
  entity — JPA entities backing `change_log_entry`, `processing_status`,
  `failed_event`, `audit_log`, `app_user`.
- **security** — JWT generation/validation filter + `UserDetailsService`
  backed by the `app_user` table.
- **config** — security rules, correlation-id filter, Swagger, Kafka
  consumer factory (docker only), cache enablement.

## Correlation IDs

Every inbound HTTP request gets (or keeps, if the caller supplied
`X-Correlation-Id`) a correlation id via `CorrelationIdFilter`, placed in
the SLF4J MDC and echoed back as a response header. The scheduled
poller/dispatcher and the Kafka consumer generate their own correlation id
per batch/message and propagate it through to `AuditLog` and `FailedEvent`
rows, so a single id lets you trace one change from capture through to
either a successful ES sync or a DLQ entry and its retries.

## Reliability properties

- **Idempotent Consumer Pattern**: `ProcessingStatus.eventId` is unique;
  `EventProcessingService.process()` short-circuits if a row already
  exists, so Kafka redelivery or scheduler re-runs never double-apply a
  change.
- **Manual acknowledgement**: `KafkaChangeConsumer` only calls
  `ack.acknowledge()` after the event is durably recorded and processed;
  a crash mid-processing causes redelivery, which idempotency then absorbs.
- **DLQ + exponential backoff**: on failure, `EventProcessingService`
  writes a `FailedEvent` with `nextRetryAt = now + initialBackoffMs`.
  `RetryService` retries anything due, doubling the backoff
  (`initialBackoffMs * multiplier^attempt`) each failure, up to
  `cdc.retry.max-attempts`, after which the event is marked `EXHAUSTED` for
  manual triage via `/api/failed-events`.
- **Horizontal scaling**: `KafkaConfig` sets consumer concurrency to 3;
  increasing partition count on the Kafka topics and running multiple
  instances of the app scales consumption further.
