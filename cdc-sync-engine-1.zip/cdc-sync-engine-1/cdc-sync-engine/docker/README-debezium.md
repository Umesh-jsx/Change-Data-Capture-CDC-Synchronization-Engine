# Registering the Debezium connector

After `docker compose up -d`, register the PostgreSQL connector with Kafka Connect:

```bash
curl -X POST -H "Content-Type: application/json" \
  --data @docker/debezium-postgres-connector.json \
  http://localhost:8083/connectors
```

Check status:
```bash
curl http://localhost:8083/connectors/orders-connector/status
```

This makes Debezium stream row-level changes on `orders`, `customers`, `products`,
`inventory`, and `payments` into Kafka topics named `dbserver1.public.<table>`,
which `KafkaChangeConsumer` (active only under the `docker` Spring profile) consumes.
